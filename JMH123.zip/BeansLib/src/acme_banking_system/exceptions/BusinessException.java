/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package acme_banking_system.exceptions;

/**
 *
 * @author Jake
 */
public class BusinessException extends Exception {

    public BusinessException(String message) {
        super(message);
    }
}
